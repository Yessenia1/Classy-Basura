# camara_rpi.py
# Clasificador de residuos en tiempo real para Raspberry Pi 4 + cámara web (PyTorch).
#
# Uso:
#   python3 camara_rpi.py                 # con ventana (escritorio de la Pi)
#   python3 camara_rpi.py --sin-ventana   # solo texto en la terminal (por SSH)
#   python3 camara_rpi.py --camara 1      # otra cámara
#   python3 camara_rpi.py --imagen foto.jpg   # clasificar una foto
# Salir: tecla q / ESC (con ventana) o Ctrl+C.
import argparse
import json
import time
import unicodedata
from collections import deque
from pathlib import Path

import cv2
import numpy as np
import torch

BASE = Path(__file__).resolve().parent
UMBRAL = 0.60
N_SUAVIZADO = 5
LADO_GUIA = 0.7

INFO = {
    "peligroso":       ("Residuo peligroso",       "ROJO",     (0, 0, 220)),
    "biological":      ("Residuo organico",        "MARRON",   (19, 69, 139)),
    "glass":           ("Vidrio",                  "VERDE",    (0, 170, 0)),
    "metal":           ("Metal",                   "AMARILLO", (0, 215, 255)),
    "paper_cardboard": ("Papel / carton",          "AZUL",     (200, 90, 0)),
    "plastic":         ("Plastico",                "BLANCO",   (255, 255, 255)),
    "trash":           ("Residuo no aprovechable", "NEGRO",    (40, 40, 40)),
}

ap = argparse.ArgumentParser()
ap.add_argument("--camara", type=int, default=0)
ap.add_argument("--sin-ventana", action="store_true")
ap.add_argument("--imagen")
args = ap.parse_args()

torch.set_num_threads(4)   # la Pi 4 tiene 4 núcleos
extra = {"clases.json": ""}
modelo = torch.jit.load(str(BASE / "modelo.pt"), map_location="cpu", _extra_files=extra)
modelo.eval()
CLASES = json.loads(extra["clases.json"])


def clasificar(bgr_cuadrado):
    """Recibe un recorte BGR (OpenCV) y devuelve las probabilidades."""
    rgb = cv2.cvtColor(cv2.resize(bgr_cuadrado, (224, 224), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
    x = torch.from_numpy(rgb.astype(np.float32))[None]   # (1, 224, 224, 3), valores 0-255
    with torch.inference_mode():
        return modelo(x)[0].numpy()


def recorte_central(frame):
    h, w = frame.shape[:2]
    lado = int(min(h, w) * LADO_GUIA)
    x0, y0 = (w - lado) // 2, (h - lado) // 2
    return frame[y0:y0 + lado, x0:x0 + lado], (x0, y0, lado)


def describir(probs):
    k = int(np.argmax(probs))
    if probs[k] < UMBRAL:
        return "No estoy seguro, acerca el objeto", (160, 160, 160)
    nombre, tacho, color = INFO[CLASES[k]]
    return f"{nombre} ({probs[k]*100:.0f}%) -> tacho {tacho}", color


def texto(img, msg, pos, escala=0.6, grosor=2):
    msg = unicodedata.normalize("NFKD", msg).encode("ascii", "ignore").decode()
    cv2.putText(img, msg, pos, cv2.FONT_HERSHEY_SIMPLEX, escala, (0, 0, 0), grosor + 3, cv2.LINE_AA)
    cv2.putText(img, msg, pos, cv2.FONT_HERSHEY_SIMPLEX, escala, (255, 255, 255), grosor, cv2.LINE_AA)


# ---------- Modo foto ----------
if args.imagen:
    img = cv2.imread(args.imagen)
    if img is None:
        raise SystemExit(f"No pude abrir {args.imagen}")
    h, w = img.shape[:2]
    lado = min(h, w)
    probs = clasificar(img[(h - lado) // 2:(h + lado) // 2, (w - lado) // 2:(w + lado) // 2])
    for k in np.argsort(probs)[::-1][:3]:
        print(f"  {CLASES[k]:16s} {probs[k]*100:5.1f}%")
    print(" ", describir(probs)[0])
    raise SystemExit

# ---------- Modo cámara ----------
cap = cv2.VideoCapture(args.camara)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)    # resolución baja = más rápido en la Pi
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
if not cap.isOpened():
    raise SystemExit(f"No pude abrir la cámara {args.camara} (prueba --camara 1)")

historial = deque(maxlen=N_SUAVIZADO)
ultimo_msg, t_prev = "", time.time()
try:
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        roi, (x0, y0, lado) = recorte_central(frame)
        historial.append(clasificar(roi))
        media = np.mean(historial, axis=0)
        msg, color = describir(media)

        ahora = time.time()
        fps = 1.0 / max(ahora - t_prev, 1e-6)
        t_prev = ahora

        if args.sin_ventana:
            if msg != ultimo_msg:
                print(f"{msg}   [{fps:.1f} FPS]", flush=True)
                ultimo_msg = msg
            continue

        h, w = frame.shape[:2]
        cv2.rectangle(frame, (x0, y0), (x0 + lado, y0 + lado), color, 3)
        cv2.rectangle(frame, (0, h - 40), (w, h), color, -1)
        texto(frame, msg, (10, h - 13), 0.6)
        for i, k in enumerate(np.argsort(media)[::-1][:3]):
            texto(frame, f"{CLASES[k]}: {media[k]*100:.0f}%", (10, 22 + i * 22), 0.5, 1)
        texto(frame, f"{fps:.1f} FPS", (w - 90, 22), 0.5, 1)
        cv2.imshow("Clasificador de residuos", frame)
        if cv2.waitKey(1) & 0xFF in (ord("q"), 27):
            break
except KeyboardInterrupt:
    pass
finally:
    cap.release()
    cv2.destroyAllWindows()
